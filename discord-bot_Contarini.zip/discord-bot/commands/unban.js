module.exports = {
    data: {
        name: 'unban',
        description: 'Revoca il ban di un utente del server.',
    },
    async execute(interaction) {
        const autore = interaction.member;
        const target = interaction.options.get('target')?.value;

        try {
            await interaction.guild.members.unban(target);
        } catch {
            await interaction.reply({ content: `Non è stato possibile revocare il ban di ${target}`, ephemeral: true });
        }

        await interaction.reply(`Il ban di **${target}** è stato revocato da **${autore.user.tag}**`)
    }
}