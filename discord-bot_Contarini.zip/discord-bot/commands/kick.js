module.exports = {
    data: {
        name: 'kick',
        description: 'Espelle un utente dal server.',
    },
    async execute(interaction) {
        const autore = interaction.member;
        const target = interaction.options.getMember('target');

        if (autore === target) {
            return await interaction.reply({ content: 'Non puoi kickare te stesso', ephemeral: true });
        }

        if (!target.kickable) {
            return await interaction.reply({ content: 'Non è possibile kickare questo utente', ephemeral: true });
        }

        if (autore.roles.highest.position <= target.roles.highest.position) {
            return await interaction.reply({ content: 'Non puoi kickare un utente di grado più alto o del tuo stesso livello', ephemeral: true });
        }

        await target.kick();

        await interaction.reply(`L'utente **${target.user.tag}** è satato kickato con successo da **${autore.user.tag}**`)
    }
}