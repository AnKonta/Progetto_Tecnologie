const { MessageEmbed } = require("discord.js")

module.exports = {
    data: {
        name: 'kennedy',
        description: 'Risponde con un embed del sito della scuola',
    },
    async execute(interaction){
        //await interaction.reply('pong');
        
        const embedEsempio = new MessageEmbed()
            .setColor('#ff0000')
            .setTitle('ITST J.F.KENNEDY')
            .setURL('https://itstkennedy.edu.it/')
            .setAuthor({name: 'Contarini Andrea', iconURL: 'https://2.bp.blogspot.com/-LCByoRNrpdY/Wgvd1VgnqrI/AAAAAAAAAPg/hVBH8VnHFVwN1EWr7ZWGsMADCA1TzdcLgCLcBGAs/s640/pure-black-wallpaper-159.jpg'})
            .setDescription('Sito della scuola')
            .setThumbnail('https://cdn-image.spaggiari.eu/pvw/custom/PNIT0003/img/PNIT0003_logo-03.png')
            .addFields(
                {
                    name: 'Regolamento Istituto e Direttiva Vigilanza',
                    value: '[Vai](https://itstkennedy.edu.it/pagine/regolamento-distituto)',
                    inline: true
                },
                {
                    name: 'News',
                    value: '[Vai](https://itstkennedy.edu.it/archivio-news)',
                    inline: true
                },
                {
                    name: 'Contatti',
                    value: '[Vai](https://itstkennedy.edu.it/pagine/contatti)',
                    inline: true
                }
            )
            .setImage('https://guidascuole.zai.net/files/scuole/thumbnails/1280/1024/PNTF01000A.jpg')
            .setFooter({text: 'Spero che ti sia stato utile'})
            .setTimestamp();
            

        await interaction.reply({ embeds: [embedEsempio] });
    }
}