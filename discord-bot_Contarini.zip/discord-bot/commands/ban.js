module.exports = {
    data: {
        name: 'ban',
        description: 'Banna un utente dal server.',
    },
    async execute(interaction) {
        const autore = interaction.member;
        const target = interaction.options.getMember('target');

        if (autore === target) {
            return await interaction.reply({ content: 'Non puoi bannare te stesso', ephemeral: true });
        }

        if (!target.bannable) {
            return await interaction.reply({ content: 'Non è possibile bannare questo utente', ephemeral: true });
        }

        if (autore.roles.highest.position <= target.roles.highest.position) {
            return await interaction.reply({ content: 'Non puoi bannare un utente di grado più alto', ephemeral: true });
        }

        await target.ban();
        await interaction.reply(`L'utente **${target.user.tag}** è satato bannato con successo da **${autore.user.tag}**.\n ID utente bannato: ${target.id}.`)
    }
}