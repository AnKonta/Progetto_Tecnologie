const dayjs = require('dayjs');
const { MessageEmbed } = require('discord.js');

module.exports = {
    data: {
        name: 'info',
        description: 'Informazioni sul server e sugli utenti!',
    },
    async execute(interaction) {
        //Controllo sottocomando
        if (interaction.options.getSubcommand() === 'user') {
            const user = interaction.options.getUser('target') ? interaction.options.getUser('target') : interaction.user;
            const member = interaction.options.getMember('target') ? interaction.options.getMember('target') : interaction.member;

            const embedUser = new MessageEmbed()
                .setAuthor({name: `${user.username}#${user.discriminator}`, iconURL: user.displayAvatarURL({ dynamic: true })})
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addField('Iscrizione a Discord', `${dayjs(user.createdAt).format('DD/MM/YYYY')}`, true)
                .addField('Ingresso nel Server', `${dayjs(member.joinedAt).format('DD/MM/YYYY')}`, true)
                .addField('Ruoli', `${member.roles.cache.map(r => `${r}`).join(', ')}`, true)
                .setFooter({text: `ID: ${user.id}`});

            await interaction.reply({ embeds: [embedUser] });

        } else if (interaction.options.getSubcommand() === 'server') {
            const guild = interaction.guild;
            const guildOwner = await guild.members.fetch(guild.ownerId);

            const tier = guild.premiumTier === 'NONE' ? '0' : guild.premiumTier.split('_')[1];

            const embedServer = new MessageEmbed()
                .setAuthor({name: guild.name, iconURL: guild.iconURL({ dynamic: true })})
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .addField('Informazioni', `
                    **Proprietario**: ${guildOwner.user.username}#${guildOwner.user.discriminator}
                    **Bootst**: ${guild.premiumSubscriptionCount} (Tier: ${tier})
                    **Creazione**: ${dayjs(guild.createdAt).format('DD/MM/YYYY')}
                `, true)
                .addField('Numeri', `
                    **Utenti**: ${guild.memberCount}
                    **Ruoli**: ${guild.roles.cache.size}
                    **Canali**: ${guild.channels.cache.size}
                        - Testuali: ${guild.channels.cache.filter(c => c.type === 'GUILD_TEXT').size}
                        - Vocali: ${guild.channels.cache.filter(c => c.type === 'GUILD_VOICE').size}
                `, true)
                .setFooter({text: `ID: ${guild.id}`});

            await interaction.reply({ embeds: [embedServer] });
    
        }
    }
}