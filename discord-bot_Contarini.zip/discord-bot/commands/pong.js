const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js")

module.exports = {
    data: {
        name: 'pong',
        description: 'Risponde con ping',
    },
    async execute(interaction){
        
        const row = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('btn_pong')
                    .setLabel('Pong')
                    .setStyle('PRIMARY')

            )
        await interaction.reply({content: 'ping', components: [row]});
    
        const collector = interaction.channel.createMessageComponentCollector()

        collector.on('collect', async i=>{
            if(i.customId === 'btn_pong'){
                await i.update({content: 'pong'})
            }
        }
        )
    }
}