const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js")

module.exports = {
    data: {
        name: 'ping',
        description: 'Risponde con pong',
    },
    async execute(interaction){
        
        const row = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('btn_ping')
                    .setLabel('Ping')
                    .setStyle('PRIMARY')

            )
        await interaction.reply({content: 'pong', components: [row]});
    
        const collector = interaction.channel.createMessageComponentCollector()

        collector.on('collect', async i=>{
            if(i.customId === 'btn_ping'){
                await i.update({content: 'ping'})
            }
        }
        )
    }
}