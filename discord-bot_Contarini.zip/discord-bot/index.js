require('dotenv').config();
const fs = require('fs');
const { Client, Collection, Intents } = require('discord.js'); //importo classe Client e Intents da discord.js
const wait = require('util').promisify(setTimeout);

const client = new Client({intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES]}) //creo un nuovo client
client.commands = new Collection();

const fileComandi = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

//Recupera comando file specifico
for(const file of fileComandi){
    const comando = require(`./commands/${file}`);
    client.commands.set(comando.data.name, comando);
}

//LISTENER

//Mando messaggio quando il bot è pronto, once indica che avviene solo una volta
client.once('ready', () => {
    console.log('Bot online');
});

//Quando viene fatto uno /command viene fatta una interaction con il bot che risponde all'evento con una interationcreate, on indica che può avvenire più volte
client.on('interactionCreate', async (interaction) => {
    if(!interaction.isCommand()) return; //Verifica se la interaction è un comando

    const nomeComando = interaction.commandName;

    if(!client.commands.has(nomeComando)) return; //Se un utente richiede un comando che non è presente viene interrotta l'esecuzione del codice

    //Messaggio all'utente se c'è un errore nell'esecuzione del comando
    try{
        await client.commands.get(nomeComando).execute(interaction);
    } catch (error){
        console.error(error);
        await interaction.reply({content: 'Qualcosa è andato storto durante l\'esecuzione del comando', ephemeral: true})
    }
});

//Quando viene scritto un messaggio avviene: 
client.on('messageCreate', async (message) => {
    //Verifica se si riesce a recuperare l'oggetto dell'owner
    if(!client.application?.owner) {
        await client.application?.fetch(); //Se non si riesce a recuperare l'oggetto dell'owner vengono recuperati i dati della application
    }

    //Controllo contenuto messaggio, verifica se il comando per registrare i comandi è stato digitato dall'owner
    if(message.content.toLowerCase() === '!registra' && message.author.id === client.application?.owner.id) {
        const data = [
            {
                name: 'ping',
                description: 'risponde con pong',
            },
            {
                name: 'pong',
                description: 'risponde con ping',
            },
            {
                name: 'echo',
                description: 'Risponde con il nostro input',
                options: [
                    {
                        name: 'input',
                        description: 'Stringa con cui il bot risponde',
                        type: 'STRING',
                        required: true, //rende obbligatorio input
                    }
                ]
            },
            {
                name: 'kennedy',
                description: 'Risponde con un embed del sito della scuola',
            },
            {
                name: 'info',
                description: 'Informazioni su un utente o sul server',
                options: [
                    {
                        name: 'user',
                        description: 'Informazioni su un utente',
                        type: 'SUB_COMMAND',
                        options: [
                            {
                                name: 'target',
                                description: 'L\'utente',
                                type: 'USER',
                            }
                        ]
                    },
                    {
                        name: 'server',
                        description: 'Informazioni sul server',
                        type: 'SUB_COMMAND'

                    }
                ]
            },
            {
                name: 'ban',
                description: 'Banna un utente dal server',
                options:[
                    {
                        name: 'target',
                        description: 'Utente da bannare',
                        type: 'USER',
                        required: true
                    }
                ]
            },
            {
                name: 'kick',
                description: 'Espelle un utente dal server',
                options:[
                    {
                        name: 'target',
                        description: 'Utente da bannare',
                        type: 'USER',
                        required: true
                    }
                ]
            },
            {
                name: 'unban',
                description: 'Revoca il ban da un utente del server',
                options:[
                    {
                        name: 'target',
                        description: 'Utente da sbannare',
                        type: 'USER',
                        required: true
                    }
                ]
            }

        ];
        
        //REGISTRO COMANDO GLOBALE (aggiornato una volta ogni ora)
        //const comando = await client.application?.commands.create(data); //la costante viene creata quando il codice viene completato
        //console.log(comando);

        //REGISTRO COMANDO GUILD (comando disponibile solo nel server in cui è registrato)
        const comando = await client.guilds.cache.get('933822585567858778')?.commands.set(data); //il comando non viene registrato direttamente nel client application ma nel client della guild specifica (ID del server)
        console.log(comando);

        //PERMESSI

        /*const comando = await client.guilds.cache.get('933822585567858778')?.commands.fetch('933822585567858778'); //Recupera lo /command, dopo il .fetch inserire l'id del comando

        const permissions = [
            {
                id: '934406541497499698', //ID del ruolo al quale vogliamo dare il permesso
                type: 'ROLE',
                permission: true
            },
            {
                id: '456848402919981058', //ID dell'utente al quale vogliamo dare il permesso
                type: 'USER',
                permission: true
            },
            {
                id: '933822585567858778',
                type: 'ROLE',
                permission: false
            }
        ];
        
        await comando.permissions.set({permissions});*/
    }
});

//Accedo con il token del bot
client.login(process.env.TOKEN);

